import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Loader2, Save } from 'lucide-react';
import { MarkdownRenderer } from './MarkdownRenderer';
import type { Project } from '@/types/project';

interface Props {
  project: Project;
  activeTab?: 'ai' | 'reasoning';
}

/** Parse verdict from DeepSeek response text */
function parseVerdict(text: string): string {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    const lower = line.toLowerCase();
    if (lower.includes('не рекомендуется')) return 'не рекомендуется';
    if (lower.includes('социальной направленности')) return 'рекомендуется с учетом социальной направленности';
    if (lower.includes('внесения изменений')) return 'рекомендуется с учетом внесения изменений';
    if (lower.includes('однозначно рекомендуется')) return 'однозначно рекомендуется';
  }
  return '';
}

export function AIAnalysisPanel({ project, activeTab = 'reasoning' }: Props) {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [dbReasoning, setDbReasoning] = useState<{ verdict: string; reasoning: string } | null>(null);
  const [dbLoading, setDbLoading] = useState(false);

  // Load existing reasoning from DB when tab opens
  useEffect(() => {
    if (activeTab !== 'reasoning') return;
    const rmMatch = project.link.match(/\/issues\/(\d+)/);
    const rmId = rmMatch ? Number(rmMatch[1]) : 0;
    if (rmId <= 0 && project.id <= 0) return;

    setDbLoading(true);
    const url = rmId > 0
      ? `api/ai_reasoning.php?rmId=${rmId}`
      : `api/ai_reasoning.php?projectId=${project.id}`;

    console.log('[AI] Loading reasoning from:', url);

    fetch(url)
      .then(r => r.json())
      .then(data => {
        console.log('[AI] Reasoning response:', data);
        if (data.ok && data.found) {
          setDbReasoning({ verdict: data.verdict, reasoning: data.reasoning });
          setAnalysis(data.reasoning);
        }
      })
      .catch(err => console.error('[AI] Load reasoning error:', err))
      .finally(() => setDbLoading(false));
  }, [activeTab, project.id, project.link]);

  const handleAnalyze = async () => {
    setLoading(true);
    setSaved(false);
    setAnalysis(null);

    const url = 'api/analyze.php';
    console.log('[AI] Sending analyze request to:', url);

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectName: project.name,
          department: project.department,
          topic: project.topic,
          effects: project.effects,
          effectType: project.effectType,
          effectAmount: project.effectAmount,
          laborClaimed: project.laborClaimed ?? 0,
          reductionPlan: project.reductionPlan,
          costTotal: project.costTotal,
          economicEffect: project.economicEffect,
          delta: project.delta,
          aiAnalysisData: project.aiAnalysis,
        }),
      });

      console.log('[AI] Response status:', response.status);

      if (!response.ok) {
        throw new Error('HTTP ' + response.status);
      }

      const result = await response.json();
      console.log('[AI] Response:', result);

      if (result.analysis) {
        setAnalysis(result.analysis);
        // Auto-save to DB
        await saveToDb(result.analysis);
      } else {
        setAnalysis('Пустой ответ от сервера.');
      }
    } catch (err) {
      console.error('[AI] Analyze error:', err);
      setAnalysis('Ошибка при запросе AI-анализа. Проверьте подключение к серверу. Ошибка: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setLoading(false);
    }
  };

  const saveToDb = async (text: string) => {
    const verdict = parseVerdict(text);
    const rmMatch = project.link.match(/\/issues\/(\d+)/);
    const rmId = rmMatch ? Number(rmMatch[1]) : 0;

    setSaving(true);
    try {
      const response = await fetch('api/ai_reasoning.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          rmId,
          verdict,
          reasoning: text,
        }),
      });
      console.log('[AI] Save to DB status:', response.status);
      setSaved(true);
      setDbReasoning({ verdict, reasoning: text });
    } catch (err) {
      console.error('[AI] Save error:', err);
    } finally {
      setSaving(false);
    }
  };

  // ── Tab: AI Data (from XLSX file) ──
  if (activeTab === 'ai') {
    if (!project.aiAnalysis || Object.keys(project.aiAnalysis).length === 0) {
      return (
        <div className="text-center py-8 text-[#718096]">
          Нет данных ИИ-аналитики из файла
        </div>
      );
    }
    return (
      <div className="space-y-3">
        <div className="text-[0.75rem] uppercase tracking-wider text-[#7c3aed] font-semibold">
          Данные из файла аналитики
        </div>
        {Object.entries(project.aiAnalysis).map(([colName, value]) => (
          <div key={colName}>
            <div className="text-[0.75rem] uppercase tracking-wider text-[#7c3aed] mb-1 font-semibold">
              {colName}
            </div>
            <div className="text-[0.9rem] text-[#1a202c] leading-relaxed whitespace-pre-wrap bg-[#faf5ff] p-4 rounded-lg">
              {value}
            </div>
          </div>
        ))}
      </div>
    );
  }

  // ── Tab: Reasoning (DeepSeek analysis) ──
  return (
    <div className="space-y-4">
      {dbLoading && (
        <div className="text-center py-4 text-[0.8rem] text-[#718096]">
          <Loader2 className="w-4 h-4 animate-spin inline mr-2" />
          Загрузка предыдущего анализа...
        </div>
      )}

      {dbReasoning && !analysis && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-[#f0f9ff] border border-[#bae6fd] rounded-lg p-4">
          <div className="text-[0.75rem] uppercase tracking-wider text-[#0369a1] mb-2 font-semibold flex items-center gap-2">
            <Save className="w-3.5 h-3.5" />
            Сохраненный анализ ({dbReasoning.verdict || 'оценка не определена'})
          </div>
          <div className="text-[0.9rem] text-[#1a202c] leading-relaxed">
            <MarkdownRenderer content={dbReasoning.reasoning} />
          </div>
        </motion.div>
      )}

      <motion.button
        onClick={handleAnalyze}
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-[#7c3aed] to-[#6d28d9] text-white rounded-xl text-[0.9rem] font-semibold border-none cursor-pointer hover:from-[#6d28d9] hover:to-[#5b21b6] transition-all disabled:opacity-60 disabled:cursor-not-allowed"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.98 }}
      >
        {loading ? (
          <><Loader2 className="w-4 h-4 animate-spin" />Анализирую...</>
        ) : (
          <><Sparkles className="w-4 h-4" />{dbReasoning ? 'Перезапустить AI-анализ обоснованности' : 'Запустить AI-анализ обоснованности'}</>
        )}
      </motion.button>

      {analysis && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <div className="text-[0.75rem] uppercase tracking-wider text-[#0e9f6e] mb-2 font-semibold flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5" />
            Результат AI-анализа
            {saved && <span className="text-[#718096] font-normal">(сохранено в БД)</span>}
          </div>
          <div className="text-[0.9rem] text-[#1a202c] leading-relaxed bg-[#f0fdf4] p-4 rounded-lg border border-[#bbf7d0] ai-analysis-content">
            <MarkdownRenderer content={analysis} />
          </div>
        </motion.div>
      )}

      {saving && (
        <div className="text-[0.8rem] text-[#718096] flex items-center gap-2">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          Сохранение в БД...
        </div>
      )}
    </div>
  );
}
