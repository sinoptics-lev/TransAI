<?php
/**
 * TransAI Upload API
 * Receives parsed project data + AI analysis and stores in DB.
 */
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Only POST method is allowed', 405);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !is_array($input)) {
    errorResponse('Invalid JSON payload');
}

$projects = isset($input['projects']) ? $input['projects'] : array();
$meta     = isset($input['meta']) ? $input['meta'] : array();

if (empty($projects) || !is_array($projects)) {
    errorResponse('No projects data provided');
}

$firstProject = $projects[0];
$requiredFields = array('name', 'department');
foreach ($requiredFields as $field) {
    if (!isset($firstProject[$field])) {
        errorResponse("Missing required field in project data: {$field}");
    }
}

$pdo = getDbConnection();

try {
    $pdo->beginTransaction();

    // Step 1: Soft-delete existing projects
    $pdo->prepare("UPDATE projects SET is_deleted = 1, deleted_at = NOW() WHERE is_deleted = 0")->execute();
    $deletedProjects = $pdo->prepare("UPDATE projects SET is_deleted = 1, deleted_at = NOW() WHERE is_deleted = 0")->rowCount();

    // Step 2: Soft-delete existing AI analysis
    $pdo->prepare("UPDATE ai_analysis SET is_deleted = 1, deleted_at = NOW() WHERE is_deleted = 0")->execute();

    // Step 3: Create new upload batch
    $stmt = $pdo->prepare("
        INSERT INTO upload_batches (rm_filename, db_filename, ai_filename, total_records, notes)
        VALUES (:rm_file, :db_file, :ai_file, :total, :notes)
    ");
    $stmt->execute(array(
        ':rm_file' => isset($meta['rmFilename']) ? $meta['rmFilename'] : '',
        ':db_file' => isset($meta['dbFilename']) ? $meta['dbFilename'] : '',
        ':ai_file' => isset($meta['aiFilename']) ? $meta['aiFilename'] : '',
        ':total'   => count($projects),
        ':notes'   => isset($meta['notes']) ? $meta['notes'] : '',
    ));
    $batchId = (int)$pdo->lastInsertId();

    // Step 4: Insert projects
    $stmt = $pdo->prepare("
        INSERT INTO projects (
            batch_id, rm_id, link, name, topic, department,
            start_date, end_date, effects, effect_type, effect_amount,
            labor_release, reduction_plan, mingos,
            cost_fot, cost_direct, cost_infra, cost_total,
            economic_effect, delta, non_material_effect,
            rm_status, db_status, db_leader, db_responsible,
            labor_claimed, reduction_actual, release_other, reduction_date
        ) VALUES (
            :batch_id, :rm_id, :link, :name, :topic, :department,
            :start_date, :end_date, :effects, :effect_type, :effect_amount,
            :labor_release, :reduction_plan, :mingos,
            :cost_fot, :cost_direct, :cost_infra, :cost_total,
            :economic_effect, :delta, :non_material_effect,
            :rm_status, :db_status, :db_leader, :db_responsible,
            :labor_claimed, :reduction_actual, :release_other, :reduction_date
        )
    ");

    // Track project_id -> rm_id mapping for AI analysis
    $projectIdMap = array(); // project_index (from frontend) -> [db_id, rm_id]

    foreach ($projects as $idx => $project) {
        $rmId = 0;
        if (!empty($project['link']) && is_string($project['link'])) {
            if (preg_match('/\/issues\/(\d+)/', $project['link'], $matches)) {
                $rmId = (int)$matches[1];
            }
        }

        $stmt->execute(array(
            ':batch_id'         => $batchId,
            ':rm_id'            => $rmId,
            ':link'             => isset($project['link']) ? $project['link'] : '',
            ':name'             => isset($project['name']) ? $project['name'] : '',
            ':topic'            => isset($project['topic']) ? $project['topic'] : '',
            ':department'       => isset($project['department']) ? $project['department'] : '',
            ':start_date'       => isset($project['startDate']) ? $project['startDate'] : '',
            ':end_date'         => isset($project['endDate']) ? $project['endDate'] : '',
            ':effects'          => isset($project['effects']) ? $project['effects'] : '',
            ':effect_type'      => isset($project['effectType']) ? $project['effectType'] : '',
            ':effect_amount'    => isset($project['effectAmount']) ? $project['effectAmount'] : 0,
            ':labor_release'    => isset($project['laborRelease']) ? $project['laborRelease'] : 0,
            ':reduction_plan'   => isset($project['reductionPlan']) ? $project['reductionPlan'] : 0,
            ':mingos'           => isset($project['mingos']) ? $project['mingos'] : '\u041d\u0435\u0442',
            ':cost_fot'         => isset($project['costFOT']) ? $project['costFOT'] : 0,
            ':cost_direct'      => isset($project['costDirect']) ? $project['costDirect'] : 0,
            ':cost_infra'       => isset($project['costInfra']) ? $project['costInfra'] : 0,
            ':cost_total'       => isset($project['costTotal']) ? $project['costTotal'] : 0,
            ':economic_effect'  => isset($project['economicEffect']) ? $project['economicEffect'] : 0,
            ':delta'            => isset($project['delta']) ? $project['delta'] : 0,
            ':non_material_effect' => isset($project['nonMaterialEffect']) ? $project['nonMaterialEffect'] : '',
            ':rm_status'        => isset($project['rmStatus']) ? $project['rmStatus'] : '',
            ':db_status'        => isset($project['dbStatus']) ? $project['dbStatus'] : '',
            ':db_leader'        => isset($project['dbLeader']) ? $project['dbLeader'] : '',
            ':db_responsible'   => isset($project['dbResponsible']) ? $project['dbResponsible'] : '',
            ':labor_claimed'    => isset($project['laborClaimed']) ? $project['laborClaimed'] : 0,
            ':reduction_actual' => isset($project['reductionActual']) ? $project['reductionActual'] : 0,
            ':release_other'    => isset($project['releaseOther']) ? $project['releaseOther'] : 0,
            ':reduction_date'   => isset($project['reductionDate']) ? $project['reductionDate'] : '',
        ));
        $projectIdMap[] = array(
            'idx'   => $idx,
            'db_id' => (int)$pdo->lastInsertId(),
            'rm_id' => $rmId,
        );
    }

    // Step 5: Insert AI analysis
    $aiInserted = 0;
    if (!empty($input['aiData']) && is_array($input['aiData'])) {
        $aiStmt = $pdo->prepare("
            INSERT INTO ai_analysis (batch_id, project_id, rm_id, col_name, col_value)
            VALUES (:batch_id, :project_id, :rm_id, :col_name, :col_value)
        ");

        // aiData is: { "rm_id": { "colName": "value", ... }, ... }
        foreach ($input['aiData'] as $rmIdStr => $analysis) {
            if (!is_array($analysis)) continue;
            $rmId = (int)$rmIdStr;

            // Find the corresponding project db_id
            $projectDbId = 0;
            foreach ($projectIdMap as $map) {
                if ($map['rm_id'] === $rmId) {
                    $projectDbId = $map['db_id'];
                    break;
                }
            }

            foreach ($analysis as $colName => $colValue) {
                $aiStmt->execute(array(
                    ':batch_id'   => $batchId,
                    ':project_id' => $projectDbId,
                    ':rm_id'      => $rmId,
                    ':col_name'   => $colName,
                    ':col_value'  => is_string($colValue) ? $colValue : json_encode($colValue),
                ));
                $aiInserted++;
            }
        }
    }

    $pdo->commit();

    successResponse(array(
        'batchId'         => $batchId,
        'inserted'        => count($projects),
        'aiInserted'      => $aiInserted,
        'previousDeleted' => $deletedProjects,
        'message'         => "Uploaded " . count($projects) . " projects, " . $aiInserted . " AI records. Previous records marked as deleted."
    ));

} catch (Exception $e) {
    $pdo->rollBack();
    errorResponse('Upload failed: ' . $e->getMessage(), 500);
}
